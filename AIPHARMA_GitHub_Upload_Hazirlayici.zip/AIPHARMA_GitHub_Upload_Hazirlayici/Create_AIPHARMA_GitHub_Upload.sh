#!/usr/bin/env bash
# Creates a safe, documentation-only web-upload folder from the user's OWN current local AIPHARMA files.
# Does not call GitHub, git push, sudo, apt, network commands, or copy science/data directories.
set -euo pipefail

SOURCE="${AIPHARMA_ROOT:-$HOME/AIPHARMA}"
DEST="${AIPHARMA_UPLOAD_DIR:-/mnt/c/Users/cobre/Downloads/AIPHARMA_GitHub_Upload}"

FILES=(
  .gitignore
  CHANGELOG.md
  CITATION.cff
  DATA_AVAILABILITY.md
  LICENSE
  LICENSE_SCOPE.md
  NOTICE
  REPRODUCIBILITY.md
  THIRD_PARTY_NOTICES.md
  VERSION
  requirements.lock
)

if [[ ! -d "$SOURCE" ]]; then
  printf 'ERROR: Source folder missing: %s\n' "$SOURCE" >&2
  exit 2
fi
if [[ -e "$DEST" ]]; then
  printf 'ERROR: Destination exists, refusing to overwrite: %s\n' "$DEST" >&2
  printf 'Rename or move the existing upload folder and rerun.\n' >&2
  exit 2
fi
for name in "${FILES[@]}"; do
  if [[ ! -f "$SOURCE/$name" || -L "$SOURCE/$name" ]]; then
    printf 'ERROR: Missing or symlinked file: %s\n' "$SOURCE/$name" >&2
    exit 2
  fi
done

# Reject obvious direct URLs or local install pointers in the lock; these need manual review before web upload.
if grep -Ein 'git\+|https?://|file://|[[:space:]]@[[:space:]]|^[[:space:]]*-e[[:space:]]' "$SOURCE/requirements.lock"; then
  printf 'ERROR: Dependency lock has URL/local references; inspect those lines before upload.\n' >&2
  exit 3
fi
# Preliminary token check: NOT a comprehensive secret scanner.
if grep -Ein '(github_pat_[A-Za-z0-9_]+|gh[pousr]_[A-Za-z0-9_]{16,}|AKIA[0-9A-Z]{16}|-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----)' "${FILES[@]/#/$SOURCE/}"; then
  printf 'ERROR: Possible credential pattern found; do not upload.\n' >&2
  exit 3
fi
if ! grep -qxF '.venv/' "$SOURCE/.gitignore"; then
  printf 'ERROR: .gitignore lacks .venv/ exclusion.\n' >&2
  exit 3
fi

mkdir -p "$DEST"
for name in "${FILES[@]}"; do
  cp -p -- "$SOURCE/$name" "$DEST/$name"
done

DEST="$DEST" python3 - <<'PY'
import hashlib, os
from pathlib import Path
root = Path(os.environ['DEST'])
expected = [
    '.gitignore', 'CHANGELOG.md', 'CITATION.cff',
    'DATA_AVAILABILITY.md', 'LICENSE', 'LICENSE_SCOPE.md',
    'NOTICE', 'REPRODUCIBILITY.md', 'THIRD_PARTY_NOTICES.md',
    'VERSION', 'requirements.lock',
]
actual = sorted(p.name for p in root.iterdir())
assert actual == sorted(expected), f'Unexpected files: {actual}'
for name in expected:
    f = root / name
    print(f'{name:30s} {f.stat().st_size:>7d} B  {hashlib.sha256(f.read_bytes()).hexdigest()[:14]}')
print('---')
print(f'OK: {len(expected)} documentation/release files copied to {root}')
print(f'Lock packages/lines: {len((root / "requirements.lock").read_text().splitlines())}')
print('GitHub website: Add file > Upload files; select the 11 FILES inside this folder, NOT the folder or a ZIP.')
print('Confirm repository is PRIVATE. This is metadata only; no actual application source code.')
PY
